//
//  ManageModel.h
//  jingdongfang
//
//  Created by mac on 16/9/9.
//  Copyright © 2016年 ZhiYu Hao. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ManageModel : NSObject


@property (nonatomic, copy) NSString *mac_id;

@property (nonatomic, copy) NSString *uid;

@property (nonatomic, copy) NSString *l_time;

@property (nonatomic, copy) NSString *s_time;

@property (nonatomic, copy) NSString *e_time;

@property (nonatomic, copy) NSString *title;

@property (nonatomic, copy) NSString *e_id;

@property (nonatomic, copy) NSString *push_type;

@property (nonatomic, copy) NSString *authoris;

@end

