//
//  ManageModel.m
//  jingdongfang
//
//  Created by mac on 16/9/9.
//  Copyright © 2016年 ZhiYu Hao. All rights reserved.
//

#import "ManageModel.h"

@implementation ManageModel


@end


