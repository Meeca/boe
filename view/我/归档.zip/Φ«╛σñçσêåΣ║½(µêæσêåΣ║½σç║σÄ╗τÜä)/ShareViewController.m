//
//  ShareViewController.m
//  jingdongfang
//
//  Created by 郝志宇 on 16/7/4.
//  Copyright © 2016年 XuDong Jin. All rights reserved.
//

#import "ShareViewController.h"
#import "ShareDeviceModel.h"
#import "ShareDeviceViewController.h"

@interface ShareViewController () <UITableViewDelegate, UITableViewDataSource>

@property (weak, nonatomic) IBOutlet UITableView *table;

@property (nonatomic, strong) NSMutableArray * myDataArray;
@property (nonatomic, strong) NSMutableArray * allDataArray;
@property (nonatomic, strong) NSArray * titles;

@property (nonatomic, assign) NSInteger page;


@end

@implementation ShareViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.title = @"设备分享";
    
    
    self.navigationItem.rightBarButtonItem = [UIBarButtonItem itemWithTitle:@"添加" target:self action:@selector(rightAddItemAction:)];

    
    
    [self.table registerClass:[UITableViewCell class] forCellReuseIdentifier:@"cell"];

    
    _page = 1;
    _myDataArray = [NSMutableArray new];
    _allDataArray = [NSMutableArray new];
    
    _titles = @[@"拥有者",@"分享者"];
    
    
    [self loadMyShareDeviceLsitFirstPage:YES];
    
    
    [self.table headerAddMJRefresh:^{
        
        _page = 1;

        [self loadMyShareDeviceLsitFirstPage:YES];
        
    }];
    
    [self.table footerAddMJRefresh:^{
        
        [self loadMyShareDeviceLsitFirstPage:NO];

        
    }];
    
    
}


-(void)rightAddItemAction:(UIBarButtonItem *)item{

    ShareDeviceViewController * vc= [[ShareDeviceViewController alloc]initWithNibName:@"ShareDeviceViewController" bundle:nil];
    [Tool setBackButtonNoTitle:self];

    [self.navigationController pushViewController:vc animated:YES];

}


/**
 *  加载设备列表（我分享出去的设备列表）
 *
 *  @param firstPage 是否是第一页
 */
- (void)loadMyShareDeviceLsitFirstPage:(BOOL )firstPage {

//get:/app.php/User/share_to_equipment_list
//    uid#用户id
    
    if (firstPage) {
        [_myDataArray removeAllObjects];
        [_allDataArray removeAllObjects];
        _page = 1;

    }
    
    
    [MCNetTool postWithUrl:@"/app.php/User/share_to_equipment_list" params:@{@"uid":kUserId,@"page":@(_page),@"pagecount":@"20"} hud:YES success:^(NSDictionary *requestDic, NSString *msg) {
        _page ++;
        
        
        
        
        NSArray * myArray =requestDic[@"my_list"];
        
        NSArray * allArray =requestDic[@"all_list"];

        
        NSArray * myModelarray = [NSArray yy_modelArrayWithClass:[My_List class] json:myArray];
        
        NSArray * allModelarray = [NSArray yy_modelArrayWithClass:[All_List class] json:allArray];

        firstPage?[_myDataArray setArray:myModelarray]:[_myDataArray addObjectsFromArray:myModelarray];
        firstPage?[_allDataArray setArray:allModelarray]:[_myDataArray addObjectsFromArray:allModelarray];

        [self.table headerEndRefresh];
        [self.table footerEndRefresh];

        [self.table reloadData];

    } fail:^(NSString *error) {
      
        [self.table headerEndRefresh];
        [self.table footerEndRefresh];

    }];

}




#pragma mark - UITableViewDelegate, UITableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return _titles.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (section==0) {
        return _myDataArray.count;
    }
    return _allDataArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    UITableViewCell *cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
    cell.textLabel.font = [UIFont systemFontOfSize:15];
//    cell.detailTextLabel.font = [UIFont systemFontOfSize:15];
    if (indexPath.section==0) {
        My_List * my_List = _myDataArray[indexPath.row];
        cell.textLabel.text = my_List.nike;
        [cell.imageView sd_setImageWithURL:[NSURL URLWithString:my_List.image] placeholderImage:[UIImage imageNamed:@"A-sousuo-1"]];
    }
    if (indexPath.section==1) {
        All_List * all_List = _allDataArray[indexPath.row];
        cell.textLabel.text = all_List.title;
        [cell.imageView sd_setImageWithURL:[NSURL URLWithString:all_List.image] placeholderImage:[UIImage imageNamed:@"A-sousuo-1"]];
        UILongPressGestureRecognizer *lo = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(longTap:)];
        [self.table addGestureRecognizer:lo];

    }
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 60;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    return .01f;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    return 40.0f;
}


- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    UILabel * title = [[UILabel  alloc]initWithFrame:CGRectMake(0, 0, KSCREENWIDTH, 40)];
     title.text = [NSString stringWithFormat:@"   %@",_titles[section]];
     return title;
}

- (void)longTap:(UIGestureRecognizer *)lon {
    if (lon.state == UIGestureRecognizerStateBegan) {
        CGPoint point = [lon locationInView:self.table];
        NSIndexPath *indexPath = [self.table indexPathForRowAtPoint:point];
        NSLog(@"section---%ld", indexPath.section);
        NSLog(@"row-------%ld", indexPath.row);

        if (indexPath != nil) {
            BlockUIAlertView *alert = [[BlockUIAlertView alloc] initWithTitle:@"删除分享用户" message:@"删除后，该用户将不能推送图片到此设备" cancelButtonTitle:@"取消" clickButton:^(NSInteger index) {
                
//                解除分享
//                
//                get:/app.php/User/shera_del
//                uid#用户id
//                mac_id#设备mac id
                
                All_List * all_List = _allDataArray[indexPath.row];

                
                
                [MCNetTool postWithUrl:@"/app.php/User/shera_del" params:@{@"uid":kUserId,@"mac_id":all_List.mac_id} hud:YES success:^(NSDictionary *requestDic, NSString *msg) {
                    
                    
                    [self showToastWithMessage:msg];
                    
                    
                    [self loadMyShareDeviceLsitFirstPage:YES];

                    
                } fail:^(NSString *error) {
                    
                    [self showToastWithMessage:error];

                }];
                
                
                
                
                
                
                
            } otherButtonTitles:@"确定"];
            [alert show];
        }
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
