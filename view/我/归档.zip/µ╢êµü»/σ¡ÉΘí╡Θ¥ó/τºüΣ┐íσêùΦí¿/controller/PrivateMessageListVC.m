//
//  PrivateMessageListVC.m
//  jingdongfang
//
//  Created by mac on 16/9/3.
//  Copyright © 2016年 ZhiYu Hao. All rights reserved.
//

#import "PrivateMessageListVC.h"
#import "PrivateMessageCell.h"
#import "PrivateMessageListFooterView.h"
#import "UIButton+Block.h"

@interface PrivateMessageListVC ()
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property(nonatomic, strong) PrivateMessageListFooterView * footerView;
@property(nonatomic, strong) UIButton *selectedBtn;//选择按钮
@property(nonatomic, strong) NSMutableArray *dataArray;
@property(nonatomic, strong) NSMutableArray *chooseArr;//选中数据的数组
@property(nonatomic, strong) NSMutableArray *markArr;//标记数据的数组
@end

@implementation PrivateMessageListVC

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
     self.navigationItem.title = @"私信";
    
    self.chooseArr = [NSMutableArray array];
    self.markArr = [NSMutableArray array];
    _dataArray = [NSMutableArray arrayWithArray:@[@"科比·布莱恩特",@"德里克·罗斯",@"勒布朗·詹姆斯",@"凯文·杜兰特",@"德怀恩·韦德",@"克里斯·保罗",@"德怀特·霍华德",@"德克·诺维斯基",@"德隆·威廉姆斯",@"斯蒂夫·纳什",@"保罗·加索尔",@"布兰顿·罗伊",@"奈特·阿奇博尔德",@"鲍勃·库西",@"埃尔文·约翰逊"]];
    //选择按钮
    _selectedBtn = [UIButton buttonWithType:UIButtonTypeSystem];
    //    _selectedBtn.frame = CGRectMake(0, 0, 60, 30);
    [_selectedBtn setTitle:@"选择" forState:UIControlStateNormal];
    [_selectedBtn setTitle:@"完成" forState:UIControlStateSelected];
    [_selectedBtn setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
    [_selectedBtn setTitleColor:RGB(248, 182, 182) forState:UIControlStateHighlighted];
    [_selectedBtn setTitleColor:[UIColor grayColor] forState:UIControlStateSelected];
    [_selectedBtn sizeToFit];
    [_selectedBtn addTarget:self action:@selector(editItemAction:) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *selectItem = [[UIBarButtonItem alloc] initWithCustomView:_selectedBtn];
    self.navigationItem.rightBarButtonItem =selectItem;

    
    
    
    [_tableView registerNib:[UINib nibWithNibName:@"PrivateMessageCell" bundle:nil] forCellReuseIdentifier:@"PrivateMessageCell"];
    _tableView.tableFooterView = [UIView new];
    
    // Do any additional setup after loading the view from its nib.
}

- (void)editItemAction:(UIButton *)item{

    item.selected =!item.selected;
    
    if (item.selected) {
        [self addFooterView];
        
    }else{
        
        [self hidenFooterView];
        
    }
    //支持同时选中多行
    self.tableView.allowsMultipleSelectionDuringEditing = YES;
    self.tableView.editing = !self.tableView.editing;
   

}

- (void)addFooterView{
    
    _footerView = [PrivateMessageListFooterView privateMessageListFooterView];
    _footerView.frame = CGRectMake(0, KSCREENHEIGHT, KSCREENWIDTH, 40);
    [self.view addSubview:_footerView];
     [UIView animateWithDuration:0.15 animations:^{
        _footerView.frame = CGRectMake(0, KSCREENHEIGHT - 40 , KSCREENWIDTH, 40);
        self.tableView.tableFooterView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, KSCREENWIDTH, 50)];
    }];
    
    [_footerView.chooseAllBtn tapControlEventTouchUpInsideWithBlock:^(UIButton *btn) {
 
        for (int i = 0; i < self.dataArray.count; i ++) {
            NSIndexPath *indexPath = [NSIndexPath indexPathForItem:i inSection:0];
            [self.tableView selectRowAtIndexPath:indexPath animated:YES scrollPosition:UITableViewScrollPositionNone];
            [self.chooseArr setArray:self.dataArray];
        }
      }];
    
    [_footerView.deleateBtn tapControlEventTouchUpInsideWithBlock:^(UIButton *btn) {
        
        
        NSLog(@"------  删除 ----  %@",_chooseArr);
        
    }];
    
}


- (void)hidenFooterView{
    [UIView animateWithDuration:0.25 animations:^{
        _footerView.frame = CGRectMake(0, KSCREENHEIGHT, KSCREENWIDTH, 40);
        self.tableView.tableFooterView = nil;
    }];
}




#pragma mark - UITableViewDelegate UITableViewDataSource
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return _dataArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    PrivateMessageCell *cell =[tableView dequeueReusableCellWithIdentifier:@"PrivateMessageCell"];
    cell.nameLab.text =_dataArray[indexPath.row];
    return cell;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return  60;
}

//选中时将选中行的在self.dataArray 中的数据添加到删除数组self.deleteArr中
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    
    if (self.tableView.editing) {
        
        [self.chooseArr addObject:[self.dataArray objectAtIndex:indexPath.row]];
        
    }else{
        
//        [tableView deselectRowAtIndexPath:indexPath animated:YES];
//        EngineerDetaileViewController * vc  = [[EngineerDetaileViewController alloc]initWithNibName:@"EngineerDetaileViewController" bundle:nil];
//        [self.navigationController pushViewController:vc animated:YES];
    }
    
    
}
//取消选中时 将存放在self.deleteArr中的数据移除
- (void)tableView:(UITableView *)tableView didDeselectRowAtIndexPath:(NSIndexPath *)indexPath  {
    
    [self.chooseArr removeObject:[self.dataArray objectAtIndex:indexPath.row]];
}









- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 10.0;
}
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 0.001f;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
