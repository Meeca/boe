//
//  MessageViewController.m
//  jingdongfang
//
//  Created by 郝志宇 on 16/6/24.
//  Copyright © 2016年 XuDong Jin. All rights reserved.
//

#import "MessageViewController.h"
#import "MessageCell.h"
#import "MessageContentCell.h"
#import "PrivateMessageListVC.h"

@interface MessageViewController ()
@property (weak, nonatomic) IBOutlet UITableView *tabelView;

@end

@implementation MessageViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.navigationItem.title = @"消息中心";
    
    
    self.navigationItem.rightBarButtonItem = [UIBarButtonItem itemWithTitle:@"私信" target:self action:@selector(sixinItemAction:)];
    
    _tabelView.rowHeight = UITableViewAutomaticDimension;
    _tabelView.estimatedRowHeight = 100;  //  随便设个不那么离谱的值
     [_tabelView registerNib:[UINib nibWithNibName:@"MessageCell" bundle:nil] forCellReuseIdentifier:@"MessageCell"];
    [_tabelView registerNib:[UINib nibWithNibName:@"MessageContentCell" bundle:nil] forCellReuseIdentifier:@"MessageContentCell"];
    _tabelView.tableFooterView = [UIView new];
    
    
}
- (void)sixinItemAction:(UIBarButtonItem *)item{

    PrivateMessageListVC * vc = [[PrivateMessageListVC alloc]initWithNibName:@"PrivateMessageListVC" bundle:nil];
    
    [self.navigationController pushViewController:vc animated:YES];


}


#pragma mark------请求消息中心接口




#pragma mark - UITableViewDelegate UITableViewDataSource
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 2;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    if (section == 0) {
        return 2;
    }
    return 10;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0) {
        MessageCell *cell =[tableView dequeueReusableCellWithIdentifier:@"MessageCell"];
        return cell;
    }
    MessageContentCell *cell =[tableView dequeueReusableCellWithIdentifier:@"MessageContentCell"];
    return cell;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if (indexPath.section == 0 ) {
        return  44;
     }
     return  44;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    
    
    
}

  
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    
    if(section == 1){
        UILabel * titleLab = [[UILabel alloc]initWithFrame:CGRectMake(0, 0,KSCREENWIDTH, 40)];
        titleLab.text = [NSString stringWithFormat:@"  %@",@"系统消息"];
        titleLab.backgroundColor = [UIColor clearColor];
        return titleLab;
     }
    return nil;
}
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 10.0;
    
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    if(section == 1){
        return 40;
    }
    return 10.0;
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
