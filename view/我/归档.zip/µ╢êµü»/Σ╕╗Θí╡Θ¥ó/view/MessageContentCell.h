//
//  MessageContentCell.h
//  jingdongfang
//
//  Created by mac on 16/9/3.
//  Copyright © 2016年 ZhiYu Hao. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MessageContentCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *contentLab;
@end
