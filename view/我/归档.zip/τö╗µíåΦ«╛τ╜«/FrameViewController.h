//
//  FrameViewController.h
//  jingdongfang
//
//  Created by 郝志宇 on 16/7/4.
//  Copyright © 2016年 XuDong Jin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FrameViewController : UIViewController

@property (nonatomic, strong) EquipmentList *list;

@end
