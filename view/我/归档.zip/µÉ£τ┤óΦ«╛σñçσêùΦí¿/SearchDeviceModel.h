//
//  SearchDeviceModel.h
//  jingdongfang
//
//  Created by mac on 16/9/8.
//  Copyright © 2016年 ZhiYu Hao. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SearchDeviceModel : NSObject


@property (nonatomic, copy) NSString *e_id;

@property (nonatomic, copy) NSString *mac_id;

@property (nonatomic, copy) NSString *title;

@property (nonatomic, copy) NSString *uid;

@property (nonatomic, copy) NSString *image;

@property (nonatomic, copy) NSString *authoris;

@end

