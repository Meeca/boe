//
//  SearchDeviceModel.m
//  jingdongfang
//
//  Created by mac on 16/9/8.
//  Copyright © 2016年 ZhiYu Hao. All rights reserved.
//

#import "SearchDeviceModel.h"

@implementation SearchDeviceModel



@end


